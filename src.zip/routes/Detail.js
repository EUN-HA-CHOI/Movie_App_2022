import React from 'react'

function Detail() {
  return (
    <div>Detail</div>
  )
}

export default Detail